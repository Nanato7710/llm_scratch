from tokenizers import Tokenizer
tok = Tokenizer.from_file("bbpe_bytelevel-100k.fixed.json")

tests = [
    "Hello, 世界 👩🏽‍💻\nZ͎͑͗́WJ🙂",
    "関数 f(x)=x^2+1 を考える。",
    "def fib(n): return 1 if n<2 else fib(n-1)+fib(n-2)",
]
for s in tests:
    ids = tok.encode(s).ids
    s2 = tok.decode(ids)
    print(s == s2, len(ids), repr(s[:20]), repr(s2[:20]))

