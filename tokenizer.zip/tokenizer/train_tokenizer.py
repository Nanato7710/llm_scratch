# train_tokenizer_fixed.py
from pathlib import Path
from tokenizers import Tokenizer
from tokenizers.models import BPE
from tokenizers.pre_tokenizers import ByteLevel
from tokenizers.trainers import BpeTrainer
from tokenizers.processors import ByteLevel as ByteLevelPost
from tokenizers.decoders import ByteLevel as ByteLevelDecoder

# 1) 入力ファイルを実在パスで指定
files = ["corpus.txt"]  # ← ここをあなたの実ファイルに合わせて明示
assert all(Path(f).exists() for f in files), f"Not found: {files}"

tok = Tokenizer(BPE(unk_token="<unk>"))
tok.pre_tokenizer = ByteLevel(add_prefix_space=True)

trainer = BpeTrainer(
    vocab_size=100_000,
    min_frequency=2,
    special_tokens=["<s>", "</s>", "<pad>", "<unk>"],
    initial_alphabet=ByteLevel.alphabet(),  # 256バイト
)

tok.train(files, trainer)

# 後処理とデコーダ
tok.post_processor = ByteLevelPost(trim_offsets=False)
tok.decoder = ByteLevelDecoder()  # add_prefix_spaceはFalse既定

tok.save("bbpe_bytelevel-100k.fixed.json")
print("saved -> bbpe_bytelevel-100k.fixed.json")

